//******************************************************************************
//   MSP430F6638 Demo - Software Toggle P4
//
//   Description: Toggle P4 by xor'ing P4 inside of a software loop.
//   ACLK = 32.768kHz, MCLK = SMCLK = default DCO~1MHz
//
//                MSP430F6638
//             -----------------
//         /|\|                 |
//          | |                 |
//          --|RST          P4.4|-->LED_RED
//            |             P4.5|-->LED_GREEN
//            |             P4.6|-->LED_YELLOW
//
//******************************************************************************

#include <msp430f6638.h>

void delay_ms(unsigned int duration);
unsigned char Is_sw1_pressed(void);
unsigned char Is_sw2_pressed(void);

void main(void)
{
  volatile unsigned int i;
  volatile unsigned int count=0;

  WDTCTL = WDTPW+WDTHOLD;                   // Stop WDT

  //Setting key port P4.2 P4.3
  P4DIR &= ~(BIT2+BIT3);//setting IO for input


  while(1)
  {
	  if(Is_sw1_pressed()==1)    	// is key 1 pressed
	  {                        		// yes
          P4DIR |= BIT4 + BIT5;              // P4.4,P4.5 set as output

          P4OUT &=  ~(BIT4 + BIT5 );			//turn off led

		  P4OUT |= BIT4;			// turn ON LED1
      }
      else
      {                        		//no
    	  P4OUT &= ~BIT4;			//turn off LED1
      }


      if(Is_sw2_pressed()==1)    	// is key 2 pressed
      {                        		// yes
          P4DIR |= BIT4 + BIT5;              // P4.4,P4.5 set as output

          P4OUT &=  ~(BIT4 + BIT5 );			//turn off led
    	  P4OUT |=BIT5; 			// turn ON LED2
      }
      else
      {                        		//no
    	  P4OUT &= ~BIT5;			//turn off LED2
      }

      //Setting key port P4.2 P4.3
      P4DIR &= ~(BIT2+BIT3);//setting IO for input

  }

}

void delay_ms(unsigned int duration)
{
	unsigned int i;
	for(i=0;i<5000*duration;i++){};
}

unsigned char Is_sw1_pressed(void)
{
    if ((P4IN & 0x04) == 0)        // is SW1 pressed?
    {                            //yes
        delay_ms(10);            // wait 10mS for debounce.
        if ((P4IN & 0x04) == 0)    // is SW1 still has pressed status after 10mS delay?
        {                        // yes, we have key press
            return 1;
        }
    }
    return 0;// if key is not pressed, return 0

}


unsigned char Is_sw2_pressed(void)
{
    if ((P4IN & 0x08) == 0)        // is SW1 pressed?
    {                            //yes
        delay_ms(10);            // wait 10mS for debounce.
        if ((P4IN & 0x08) == 0)    // is SW1 still has pressed status after 10mS delay?
        {                        // yes, we have key press
            return 1;
        }
    }
    return 0;// if key is not pressed, return 0

}

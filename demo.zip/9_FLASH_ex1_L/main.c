#include "inc/hw_memmap.h"
#include "driverlib/5xx_6xx/flash.h"
#include "driverlib/5xx_6xx/wdt.h"
#include "driverlib/5xx_6xx/gpio.h"
#include "stdint.h"
#include <msp430.h>

//  ��ʼ��FLASH��Ϣ��D(Info D)ָ�룬ָ��Info D�׵�ַ���������԰�0x1800�ĳ�0x18000
#define  FLASH_ptrD   0x1800

uint32_t value = 0x12345678;

void main (void)
{
    uint8_t status;

    // �رտ��Ź���ʱ��
    WDT_hold(__MSP430_BASEADDRESS_WDT_A__);

    // ��P4.5Ϊ�������
    GPIO_setAsOutputPin(__MSP430_BASEADDRESS_PORT4_R__,
                        GPIO_PORT_P4,
                        GPIO_PIN5);

    // ����FLASH Info D��
    do {
        Flash_segmentErase(__MSP430_BASEADDRESS_FLASH__,
                           (uint8_t *)FLASH_ptrD);
        status = Flash_eraseCheck(__MSP430_BASEADDRESS_FLASH__,
                                  (uint8_t *)FLASH_ptrD,
                                  128);
    } while (status == STATUS_FAIL);

    // дFLASH����
    Flash_write32(__MSP430_BASEADDRESS_FLASH__,
                  &value,
                  (uint32_t *)(FLASH_ptrD),1);

    while (1)
    {
        // ��д��ϣ���˸ָʾ��
        GPIO_toggleOutputOnPin(__MSP430_BASEADDRESS_PORT4_R__,
                               GPIO_PORT_P4,
                               GPIO_PIN5);

         __delay_cycles(1000000);
    }
}


#include"msp430f6638.h"
void main(void)
{

	WDTCTL = WDTPW+WDTHOLD;                   // Stop WDT
	//setting direction
	P4DIR &= ~(BIT2);                          //setting IO for input
    P4DIR |= BIT4+BIT5+BIT6;                   // P4.4,P4.5,P4.6 set as output

  while (1)
   {


	if ((P4IN & 0x04) == 0)                     //If key is pressed
	{
		P4OUT |= BIT4+BIT5+BIT6;                //led on
 	}
	else
	{
	    P4OUT &=~(BIT4+BIT5+BIT6);              // led off
	}

   }
}

#include <msp430f6638.h>
#include "stdint.h"

#define  NumToWrite	  128

void main(void)
{

	uint8_t  i;
	uint8_t	 *RAM_ptr = (uint8_t *) 0x4400;
	WDTCTL = WDTPW + WDTHOLD;					// Stop WDT
	P4DIR |= BIT5;

	for(i=0; i<NumToWrite; i++)
	{
		*RAM_ptr++ = i;
	}
	RAM_ptr = (uint8_t *) 0x4400;
	__no_operation();                    // Loop forever, SET BREAKPOINT HERE

	RCCTL0 = RCKEY + RCRS2OFF;

	while(1)
	{
	  P4OUT ^= BIT5;
	   //Delay
	  __delay_cycles(1000000);
	}
}

/**
  ******************************************************************************
  * @�ļ��� TM1638.c
  * @����   DY
  * @�汾   V3.0
  * @����   08/21/2013
  * @ժҪ   TM1638Դ�ļ�
  ******************************************************************************
  * @Copyright (c)2013,�Ϻ����е��ӿƼ����޹�˾
  * @All right reserved.
  */
/* Includes ------------------------------------------------------------------*/
#include "TM1638.h"
#include "msp430f6638.h"


/* Private variables ---------------------------------------------------------*/
uint8_t num[8]; //�����������ʾ��ֵ
uint8_t led_flag[8];
const uint8_t tab[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};

/* Private functions ---------------------------------------------------------*/
void init_port(void)
{
	P3DIR |= BIT5;
	P3DIR |= BIT4 + BIT2;

	P1DIR |= BIT0;                            	// ACLK set out to pins
	P1SEL |= BIT0;
//	P3DIR |= BIT4;                            	// SMCLK set out to pins
//	P3SEL |= BIT4;
}
int main(void)
{
	unsigned int i = 0;
	unsigned char count;
	WDTCTL = WDTPW+WDTHOLD;
	init_port();
	init_TM1638();
	while(1)
	  {
		   i=Read_key();
		   if(i<16)
			{
				 while(Read_key()==i);  //�ȴ������ͷ�
				 num[0] = tab[i];
				 Write_DATA(0*2,num[3]);//д��i�������
				 Write_DATA(1*2,num[2]);
				 Write_DATA(2*2,num[1]);
				 Write_DATA(3*2,num[0]);
				 Write_DATA(4*2,num[7]);
				 Write_DATA(5*2,num[6]);
				 Write_DATA(6*2,num[5]);
				 Write_DATA(7*2,num[4]);
				 for(count=7;count>0;count--)
				 {
					 num[count] = num[count-1];
				 }
			}
	  }
}


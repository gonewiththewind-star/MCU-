//******************************************************************************
//   MSP430F6638 Demo - Software Toggle P4
//
//   Description: Toggle P4 by xor'ing P4 inside of a software loop.
//   ACLK = 32.768kHz, MCLK = SMCLK = default DCO~1MHz
//
//                MSP430F6638
//             -----------------
//         /|\|                 |
//          | |                 |
//          --|RST          P4.4|-->LED_RED
//            |             P4.5|-->LED_GREEN
//            |             P4.6|-->LED_YELLOW
//
//******************************************************************************

#define P3P4_BASE_Address 0x0220

#define BIT4                   (0x0010)
#define BIT5                   (0x0020)
#define BIT6                   (0x0040)


#define P4DIR  (*((volatile unsigned char*)(P3P4_BASE_Address + 0x05)))
#define P4OUT 	(*((volatile unsigned char*)(P3P4_BASE_Address + 0x03)))


void main(void)
{
  volatile unsigned int i;
  volatile unsigned int count=0;

  P4DIR |= BIT4 + BIT5 + BIT6;              // P4.4,P4.5,P4.6 set as output

  while(1)                                  // continuous loop
  {
    P4OUT ^= BIT4 + BIT5 + BIT6;            // XOR P4.4,P4.5,P4.6
    for(i=50000;i>0;i--);                   // Delay
  }
}

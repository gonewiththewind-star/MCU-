//******************************************************************************
//   MSP430F6638 Demo - Software Toggle P4
//
//   Description: Toggle P4 by xor'ing P4 inside of a software loop.
//   ACLK = 32.768kHz, MCLK = SMCLK = default DCO~1MHz
//
//                MSP430F6638
//             -----------------
//         /|\|                 |
//          | |                 |
//          --|RST          P4.4|-->LED_RED
//     KEY1-->|P4.2         P4.5|-->LED_GREEN
//            |             P4.6|-->LED_YELLOW
//
//******************************************************************************
#include"msp430f6638.h"
unsigned char flag;
void main(void)
{
        WDTCTL = WDTPW+WDTHOLD;                                    // Stop WDT

        P4DIR &=~(BIT2);
        P4DIR |= BIT4+BIT5+BIT6;                                   // P4.4,P4.5,P4.6 set as output
        P4OUT &=~(BIT4+BIT5+BIT6);                                 // set led off

        P2IE |= BIT6;                                              // enable P2.6 interrupt
        P2IFG &= ~(BIT6);                                            // clean interrupt flag
        __enable_interrupt();                                      // enable interrupt
        while(1)
        {
        	if((P4IN & 0x04)==0)
        	{
        		P2IFG |= BIT6;
        	}
        	else
        	{
        		P2IFG &=~BIT6;
        	}
        }
}


// PORT2 interrupt service routine
#pragma vector=PORT2_VECTOR
__interrupt void port_2(void)
{
	                P4OUT ^=(BIT4+BIT5+BIT6);                                 // set led on
	            	P2IFG &=~BIT6;                                        // clean interrupt flag

}

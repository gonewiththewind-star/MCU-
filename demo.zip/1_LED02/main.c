//******************************************************************************
//   MSP430F6638 Demo - Software Toggle P4
//
//   Description: Toggle P4 by xor'ing P4 inside of a software loop.
//   ACLK = 32.768kHz, MCLK = SMCLK = default DCO~1MHz
//
//                MSP430F6638
//             -----------------
//         /|\|                 |
//          | |                 |
//          --|RST          P4.4|-->LED_RED
//            |             P4.5|-->LED_GREEN
//            |             P4.6|-->LED_YELLOW
//
//******************************************************************************

#include <msp430f6638.h>

void main(void)
{
  volatile unsigned int i;
  volatile unsigned int count=0;

  WDTCTL = WDTPW+WDTHOLD;                   // Stop WDT
  P4DIR |= BIT4 + BIT5 + BIT6;              // P4.4,P4.5,P4.6 set as output

 // P4OUT = 0x00;
  P4OUT &= ~(BIT4 + BIT5 + BIT6);

  while(1)                                  // continuous loop
  {
    P4OUT ^= BIT4 + BIT5 + BIT6;            // XOR P4.4,P4.5,P4.6
    for(i=20000;i>0;i--);                   // Delay
  }
}

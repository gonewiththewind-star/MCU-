//******************************************************************************
//  MSP430F66x Demo - Timer0_A5, Toggle P1.0, CCR0 Up Mode ISR, DCO SMCLK
//
//  Description: Toggle P1.0 using software and TA_0 ISR. Timer0_A is
//  configured for up mode, thus the timer overflows when TAR counts
//  to CCR0. In this example, CCR0 is loaded with 50000.
//  ACLK = n/a, MCLK = SMCLK = TACLK = default DCO ~1.045MHz
//
//	Timer0_A�����ó����ϼ���ģʽ����0��ʼ������CCR0��CCR0��ֵΪ50000.����������CCR0֮��
//	��������жϡ����жϷ�������У���תLED�ơ�
//
//           MSP430F66x
//         ---------------
//     /|\|               |
//      | |               |
//      --|RST        p4.4|-->LED
//        |           P4.5|-->LED
//        |           P4.6|-->LED
//
//******************************************************************************

#include <msp430f6638.h>

void main(void)
{
  WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
  P4OUT &= ~(BIT4 + BIT5 + BIT6);
  P4DIR |= BIT4+BIT5+BIT6;                  // P1.0 output
  TA0CCTL0 = CCIE;                          // CCR0 interrupt enabled
  TA0CCR0 = 50000;
  TA0CTL = TASSEL_2 + MC_1 + TACLR;         // SMCLK, up mode, clear TAR

  __bis_SR_register(LPM0_bits + GIE);       // Enter LPM0, enable interrupts
  __no_operation();                         // For debugger
}

// Timer0 A0 interrupt service routine
#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{
	static int cnt = 0;
	if(cnt == 3)
	{
		P4OUT ^= BIT4+BIT5+BIT6;             // Toggle P1.0
		cnt = 0;
	}
	else
		cnt++;
}
